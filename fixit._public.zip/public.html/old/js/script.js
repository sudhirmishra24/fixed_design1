function toggleSearchBox() {
    const box = document.getElementById('search-box');
    box.classList.toggle('hidden');
  }
  